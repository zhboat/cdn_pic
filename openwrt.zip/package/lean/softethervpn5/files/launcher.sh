#!/bin/sh
exec "/usr/libexec/softethervpn/${0##*/}" "$@"

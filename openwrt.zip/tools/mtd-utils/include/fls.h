#include <string.h>
#define fls local_fls
